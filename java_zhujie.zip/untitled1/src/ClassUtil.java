import com.sun.java.util.jar.pack.*;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

/**
 * Created by 周书梅 on 2017/7/30.
 */
public class ClassUtil {
    public static void printMethodMessage(Object obj){
        Class c=obj.getClass();
        System.out.println("类的名称是："+c.getName());
        /*获取方法及参数类型*/
        Method[] ms=c.getMethods();
        for(int i=0;i<ms.length;i++){
            //得到方法的返回值类的类类型；
            Class returnType=ms[i].getReturnType();
            System.out.print(returnType.getName()+" ");
            System.out.print(ms[i].getName()+"(");

            Class[] paramTypes=ms[i].getParameterTypes();

            for (Class class1:paramTypes) {
                System.out.print(class1.getName()+",");
            }
            System.out.println(")");
        }

    }
    /*获取关于成员变量的一些信息*/
    public static void printFieldMessage(Object obj) {
        Class c=obj.getClass();
        Field[] fs=c.getDeclaredFields();//这个方法包括所有的变量；
        for (Field field:fs) {
            //得到成员变量类型的类类型，若果是int，得到int.class;
            Class fieldType=field.getType();
            String typeName=fieldType.getName();

            //得到成员变量的名字；
            String fieldName=field.getName();

            System.out.println(typeName+" ,"+fieldName);
        }
    }
    /*获取构造函数的一些信息*/
    public static void printConMessage(Object obj){
        Class c=obj.getClass();
        //得到所有的构造函数；
        Constructor[] cs=c.getDeclaredConstructors();
        for (Constructor constructor:cs) {
            System.out.print(constructor.getName()+"(");
            //获取构造函数的参数列表；
            Class[] paramTypes=constructor.getParameterTypes();
            for (Class class1:paramTypes) {
                System.out.print(class1.getName()+",");

            }
            System.out.println(")");
        }
    }
}
