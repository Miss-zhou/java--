import java.lang.reflect.Method;

/**
 * Created by 周书梅 on 2017/7/30.
 */
public class MethodReflect {
    public static void main(String[] args){
        A a1=new A();
        Class c=a1.getClass();
        try {
            //两种方法都是可以的；
            //Method m=c.getDeclaredMethod("print", new Class[]{int.class, int.class});
            Method m=c.getDeclaredMethod("print", int.class, int.class);
            //方法的反射是用m来调用print犯法，和a1.print的效果完全相同；
            //方法如果有返回类型，就返回，如果没有，就返回null；
            //Object o=m.invoke(a1,new Object[]{10,20});or next
            Object o=m.invoke(a1,10,20);

            Method m1=c.getDeclaredMethod("print", String.class, String.class);
            Object o1=m1.invoke(a1,"hello","world");

            //下面这句话等价于 Method m2=c.getDeclaredMethod("print");
            Method m2=c.getDeclaredMethod("print",new Class[]{});
            //下面这句话等价于Object O2=m2.invoke(a1);
            Object O2=m2.invoke(a1,new Object[]{});

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
class A{
    public static void print(){
        System.out.println("hello world!");
    }
    public void print(int a,int b){
        System.out.println(a+b);
    }
    public void print(String a,String b){
        System.out.println(a.toUpperCase()+","+b.toLowerCase());
    }
}
