import java.lang.reflect.Method;
import java.util.*;

public class Main {

    public static void main(String[] args) {
        /*String s="hello world";
        //ClassUtil.printConMessage(s);
        ClassUtil.printConMessage(new Integer(1));
        //ClassUtil.printMethodMessage(new Integer(1));*/

        //下面这个实例证明了泛型在编译之后是去泛型化的，是为了避免错误的输出，此时c==c1；
        ArrayList list=new ArrayList();
        Class c=list.getClass();

        ArrayList<String> list1=new ArrayList<String>();
        Class c1=list1.getClass();
        list1.add("hello");
        //通过反射来绕过编译；原先的只能输入字符串的list2反射之后可以输入其他的类型；
        try {
            Method m=c1.getDeclaredMethod("add", Object.class);
            m.invoke(list1,1);
            System.out.println(list1.size());
            System.out.println(list1);
        }catch (Exception e){
            e.printStackTrace();
        }
        System.out.println(c1==c);
    }
}
